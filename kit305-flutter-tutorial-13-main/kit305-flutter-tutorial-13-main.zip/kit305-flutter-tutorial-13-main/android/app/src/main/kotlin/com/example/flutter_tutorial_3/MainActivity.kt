package com.example.kit305_flutter_tutorial_13_main

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
